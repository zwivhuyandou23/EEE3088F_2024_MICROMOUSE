# pylint: disable=missing-module-docstring
from .plugin import JLCPCBPlugin

JLCPCBPlugin().register()
