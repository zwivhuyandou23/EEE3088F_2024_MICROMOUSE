# EEE2046Pracs

## [VSCode C-programming setup](https://github.com/Agi23/EEE2046Pracs/tree/main/C-programming)
Tutorial on how to setup your device for C-programming using the VSCode IDE. You are required to have this ready for Practical 3.
## [STM32 Testing](https://github.com/Agi23/EEE2046Pracs/tree/main/STM32)
Tutorial for after you have completed the soldering tutorial showing you how to update your ST-LINK and download a demo program. You will need to have a functional board for Practical 4.

## [VSCode for STM32 Development](https://github.com/Agi23/EEE2046Pracs/tree/main/VSCode%20for%20STM32%20Development)
Tutorial on how to set up your VSCode environment to work with the STM32 board. A template is provided and instructions are given on how to write code for your STM32 dev board. This development environment is required for Practical 4.
